#include <iostream>

int main(int, char **)
{
        std::cout << "Hello, World!\n";
        return 0;
}
