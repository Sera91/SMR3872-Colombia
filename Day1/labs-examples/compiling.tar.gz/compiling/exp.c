#include <math.h>
#include <stdio.h>

int main(int argc, char **argv) {
  double a=2.0;
  printf("exp(2.0) = %f\n",exp(a));
  return 0;
}
