#!/usr/bin/env python

from hello import *

print("Calling Fortran subroutine")
hello()
print("Done")
