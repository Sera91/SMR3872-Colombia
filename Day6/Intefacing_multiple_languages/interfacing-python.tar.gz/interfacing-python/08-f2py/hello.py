#!/usr/bin/env python

from  hello import *

print ("Calling DSO")
hello('World')
print ("Done")

