#!/bin/bash
#SBATCH -N 2
#SBATCH --ntasks-per-node=16
#SBATCH --cpus-per-task=1
#SBATCH --time=00:05:00 
#SBATCH --output job.out
#SBATCH --error job.err
#SBATCH --partition long

mpirun ./exec_script_example.sh



